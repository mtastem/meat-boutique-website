# MEAT BOUTIQUE — Board-Grade Brand Website

Premium board presentation and future consumer website for Meat Boutique, Lebanon's first premium frozen beef and lamb service platform.

## Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

Visit [http://localhost:3000](http://localhost:3000)

## Tech Stack

- **Framework:** Next.js 14 (App Router)
- **Styling:** Tailwind CSS
- **Language:** TypeScript
- **Fonts:** Playfair Display (serif) + Montserrat (sans) via Google Fonts
- **Deployment:** Vercel-ready

## Design Tokens

### Colors
| Token | Hex | Usage |
|-------|-----|-------|
| `brand-black` | `#0A0A0A` | Primary background, bands |
| `brand-gold` | `#C9A96E` | Primary accent, all text on dark |
| `brand-burgundy` | `#6B2D4A` | Emotional accent, box interior |
| `brand-cream` | `#F5F0E8` | Light sections, body text |
| `brand-gray` | `#888888` | Secondary text |
| `brand-darkgray` | `#1A1A1A` | Card backgrounds |

### Typography
- **Headings:** Playfair Display (serif), Bold, tracking-wide
- **Body:** Montserrat (sans), 300–600 weight
- **Labels:** Montserrat, 9–10px, tracking-[0.2em], uppercase

## Site Structure

```
src/
├── app/
│   ├── globals.css          # Global styles + font import
│   ├── layout.tsx           # Root layout with metadata
│   └── page.tsx             # Complete homepage with all sections
├── components/
│   ├── Navigation.tsx       # Fixed nav with mobile menu
│   └── Sections.tsx         # Reusable components (Section, cards, bag mockup)
```

## Sections (in order)

1. **Hero** — "Certainty in every cut" with gold CTA
2. **Thesis** — What Meat Boutique is and the category it creates
3. **Problem** — Market comparison (Butcher vs Supermarket vs Import vs MB)
4. **Products** — Full product universe across 8 categories
5. **Packaging** — Master bag system with 3 sizes + spec cards
6. **Box Experience** — Signature vs Service box with unboxing sequence
7. **Trust & Education** — 5 trust pillars + education framework
8. **Channels** — 4 sales channels + customer repeat loop
9. **Platform** — GFS → Prime Lab → Meat Boutique stack + metrics
10. **Growth** — 6 future growth vectors
11. **CTA** — "The category is open" conversion section
12. **Footer** — Navigation + confidential note

## How to Edit Content

All content lives in `src/app/page.tsx` as data arrays. To change any section:

1. Find the section by its `id` attribute or comment header
2. Edit the text directly in the JSX
3. For card-based sections, edit the array of objects before the `.map()` call

Example — to change a product card:
```tsx
{ cat: "Premium Steaks", position: "Reserve Halo", examples: "Ribeye, Tenderloin", feel: "Aspirational." },
```

## How to Change Visuals

- **Colors:** Edit `tailwind.config.ts` → `theme.extend.colors.brand`
- **Fonts:** Edit the Google Fonts import URL in `src/app/globals.css`
- **Spacing:** Sections use `py-20 md:py-32` — adjust in `Sections.tsx`
- **Animations:** Edit keyframes in `tailwind.config.ts` → `theme.extend.keyframes`

## Deploy to Vercel

1. Push to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import the repository
4. Framework: Next.js (auto-detected)
5. Deploy

Or use CLI:
```bash
npx vercel
```

## Brand Rules

### Do
- Use gold (#C9A96E) for all text on dark backgrounds
- Use Playfair Display for headings, Montserrat for body
- Alternate dark and light sections for rhythm
- Keep burgundy to 15-20% accent only

### Don't
- Never use flat yellow instead of gold
- Never use white backgrounds for hero/packaging sections
- Never mix different blacks across sections
- Never use burgundy as a primary color
