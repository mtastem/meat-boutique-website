"use client";
import { useEffect, useRef, useState, ReactNode } from "react";

/* ── Animated section wrapper ── */
export function Section({
  id,
  className = "",
  children,
  dark = true,
}: {
  id?: string;
  className?: string;
  children: ReactNode;
  dark?: boolean;
}) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id={id}
      ref={ref}
      className={`relative px-6 md:px-12 lg:px-20 py-20 md:py-32 transition-all duration-1000 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${dark ? "bg-brand-black" : "bg-brand-cream"} ${className}`}
    >
      <div className="max-w-7xl mx-auto">{children}</div>
    </section>
  );
}

/* ── Gold divider line ── */
export function GoldDivider({ className = "" }: { className?: string }) {
  return (
    <div className={`flex justify-center ${className}`}>
      <div className="w-16 h-px bg-gradient-to-r from-transparent via-brand-gold to-transparent" />
    </div>
  );
}

/* ── Section heading ── */
export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p className="font-sans text-[10px] md:text-xs tracking-[0.3em] uppercase text-brand-gold/70 mb-4">
      {children}
    </p>
  );
}

export function SectionTitle({
  children,
  light = false,
}: {
  children: ReactNode;
  light?: boolean;
}) {
  return (
    <h2
      className={`font-serif text-3xl md:text-4xl lg:text-5xl font-bold leading-tight tracking-wide mb-6 ${
        light ? "text-brand-black" : "text-brand-gold"
      }`}
    >
      {children}
    </h2>
  );
}

/* ── Metric card ── */
export function MetricCard({
  value,
  label,
  sub,
}: {
  value: string;
  label: string;
  sub?: string;
}) {
  return (
    <div className="border border-brand-gold/15 rounded-lg p-6 text-center hover:border-brand-gold/30 transition-colors duration-500">
      <div className="font-serif text-3xl md:text-4xl text-brand-gold font-bold mb-2">
        {value}
      </div>
      <div className="font-sans text-sm text-brand-cream/80 tracking-wide uppercase">
        {label}
      </div>
      {sub && (
        <div className="font-sans text-xs text-brand-gray mt-1">{sub}</div>
      )}
    </div>
  );
}

/* ── Feature card ── */
export function FeatureCard({
  title,
  description,
  accent = false,
}: {
  title: string;
  description: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`rounded-lg p-6 md:p-8 border transition-all duration-500 hover:-translate-y-1 ${
        accent
          ? "border-brand-gold/30 bg-brand-gold/5"
          : "border-white/5 bg-white/[0.02] hover:border-brand-gold/15"
      }`}
    >
      <h3 className="font-serif text-lg md:text-xl text-brand-gold mb-3">
        {title}
      </h3>
      <p className="font-sans text-sm text-brand-gray leading-relaxed">
        {description}
      </p>
    </div>
  );
}

/* ── Packaging bag visual ── */
export function BagMockup({
  size,
  cutName,
  weight,
  reserve = false,
  className = "",
}: {
  size: "sm" | "md" | "lg";
  cutName: string;
  weight: string;
  reserve?: boolean;
  className?: string;
}) {
  const dims = {
    sm: "w-28 h-44",
    md: "w-36 h-56",
    lg: "w-44 h-64",
  };

  return (
    <div className={`${dims[size]} rounded-md overflow-hidden shadow-2xl relative ${className}`}>
      {/* Top band */}
      <div className="absolute top-0 left-0 right-0 h-[22%] bg-brand-black flex flex-col items-center justify-center px-2 z-10">
        <span className="font-serif text-brand-gold text-[8px] md:text-[10px] font-bold tracking-[0.15em] text-center leading-tight">
          MEAT<br />BOUTIQUE
        </span>
        <div className="w-6 h-px bg-gradient-to-r from-transparent via-brand-gold to-transparent mt-1" />
      </div>

      {/* Window */}
      <div className="absolute top-[22%] left-0 right-0 h-[56%] bg-gradient-to-br from-[#e8ddd0] to-[#c8b9a4]">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-3/4 h-3/4 rounded-full bg-[#7B3B10]/10" />
        </div>
      </div>

      {/* Reserve seal */}
      {reserve && (
        <div className="absolute top-[22%] right-0 bg-brand-burgundy text-brand-gold text-[5px] font-sans font-semibold tracking-wider uppercase px-1.5 py-0.5 z-10">
          Reserve
        </div>
      )}

      {/* Bottom band */}
      <div className="absolute bottom-0 left-0 right-0 h-[22%] bg-brand-black flex flex-col items-center justify-center px-2 z-10">
        <span className="font-serif text-brand-gold text-[8px] md:text-[9px] tracking-wide">
          {cutName}
        </span>
        <div className="w-5 h-px bg-gradient-to-r from-transparent via-brand-gold to-transparent mt-0.5 mb-0.5" />
        <span className="font-sans text-[5px] text-brand-gray tracking-widest uppercase">
          {weight}
        </span>
      </div>

      {/* Corner accents */}
      <div className="absolute top-1 left-1 w-2 h-2 border-t border-l border-brand-gold/20" />
      <div className="absolute top-1 right-1 w-2 h-2 border-t border-r border-brand-gold/20" />
      <div className="absolute bottom-1 left-1 w-2 h-2 border-b border-l border-brand-gold/20" />
      <div className="absolute bottom-1 right-1 w-2 h-2 border-b border-r border-brand-gold/20" />
    </div>
  );
}
