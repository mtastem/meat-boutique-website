import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MEAT BOUTIQUE — Premium Frozen Beef & Lamb Service",
  description: "Lebanon's first premium frozen beef and lamb service platform. Sourced by professionals. Portioned perfectly. Delivered with confidence.",
  openGraph: {
    title: "MEAT BOUTIQUE",
    description: "Certainty in every cut. Premium frozen beef and lamb, reimagined.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
