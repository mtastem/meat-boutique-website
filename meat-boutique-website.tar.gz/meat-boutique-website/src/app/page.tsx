import Navigation from "@/components/Navigation";
import {
  Section,
  GoldDivider,
  SectionLabel,
  SectionTitle,
  MetricCard,
  FeatureCard,
  BagMockup,
} from "@/components/Sections";

/* ═══════════════════════════════════════════
   MEAT BOUTIQUE — Board-Grade Brand Website
   ═══════════════════════════════════════════ */

export default function Home() {
  return (
    <main className="relative overflow-hidden">
      <Navigation />

      {/* ════════ HERO ════════ */}
      <section className="relative min-h-screen flex items-center justify-center px-6 md:px-12 bg-brand-black overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 bg-gradient-to-br from-brand-black via-brand-black to-[#1a1208] opacity-60" />
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-brand-gold/[0.03] rounded-full blur-3xl" />

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <p className="font-sans text-[10px] md:text-xs tracking-[0.4em] uppercase text-brand-gold/60 mb-8">
            Premium Frozen Beef &amp; Lamb Service
          </p>

          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-brand-gold tracking-wide leading-[1.1] mb-8">
            Certainty in<br />every cut.
          </h1>

          <GoldDivider className="mb-8" />

          <p className="font-sans text-sm md:text-base text-brand-cream/60 max-w-2xl mx-auto leading-relaxed mb-12">
            Lebanon&apos;s first premium frozen beef and lamb service platform.
            Sourced by professionals. Portioned perfectly. Delivered with confidence.
          </p>

          <a
            href="#thesis"
            className="inline-block px-8 py-3 bg-brand-gold text-brand-black font-sans text-xs tracking-[0.2em] uppercase font-semibold rounded-sm hover:bg-brand-gold/90 transition-colors duration-300"
          >
            Explore the Vision
          </a>

          {/* Scroll indicator */}
          <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
            <span className="font-sans text-[9px] tracking-[0.2em] uppercase text-brand-gray/50">Scroll</span>
            <div className="w-px h-8 bg-gradient-to-b from-brand-gold/30 to-transparent" />
          </div>
        </div>

        {/* Burgundy accent line */}
        <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-gradient-to-r from-brand-burgundy via-brand-burgundy/50 to-transparent" />
      </section>

      {/* ════════ THESIS ════════ */}
      <Section id="thesis">
        <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-start">
          <div>
            <SectionLabel>The Thesis</SectionLabel>
            <SectionTitle>A new category,<br />built from truth.</SectionTitle>
            <p className="font-sans text-sm md:text-base text-brand-cream/50 leading-relaxed">
              Meat Boutique is Lebanon&apos;s first purpose-built premium frozen beef and lamb
              service platform. Not a butcher. Not a frozen food brand. Not a chef&apos;s side
              project. A dedicated consumer-service system that transforms imported,
              professionally processed protein into portioned, branded, beautifully
              packaged products designed for household confidence.
            </p>
          </div>
          <div className="space-y-6">
            <div className="border-l-2 border-brand-gold/30 pl-6">
              <h3 className="font-serif text-lg text-brand-gold mb-2">Category Created</h3>
              <p className="font-sans text-sm text-brand-gray">
                The Curated Protein Service — above the butcher, beyond the supermarket, ahead of generic imports.
              </p>
            </div>
            <div className="border-l-2 border-brand-gold/30 pl-6">
              <h3 className="font-serif text-lg text-brand-gold mb-2">Emotional Promise</h3>
              <p className="font-sans text-sm text-brand-gray">
                Confidence. Control. Pride. The certainty that what is in your freezer will perform perfectly on your table.
              </p>
            </div>
            <div className="border-l-2 border-brand-gold/30 pl-6">
              <h3 className="font-serif text-lg text-brand-gold mb-2">What It Is Not</h3>
              <p className="font-sans text-sm text-brand-gray">
                Not cheap frozen meat. Not a vanity brand. Not a subscription trap. Not luxury without purpose.
              </p>
            </div>
          </div>
        </div>
      </Section>

      {/* ════════ PROBLEM ════════ */}
      <Section id="problem">
        <SectionLabel>The Problem</SectionLabel>
        <SectionTitle>The market is broken<br />in three places.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-cream/50 max-w-3xl leading-relaxed mb-16">
          Lebanese households love quality meat. But every existing option forces a compromise —
          trust without convenience, convenience without quality, or quality without consistency.
        </p>

        <div className="grid md:grid-cols-4 gap-6">
          {[
            { title: "Butcher", trust: "High (personal)", consistency: "Low", portioning: "None", branding: "None", education: "None", highlight: false },
            { title: "Supermarket Frozen", trust: "Low", consistency: "Medium", portioning: "Basic", branding: "Weak", education: "None", highlight: false },
            { title: "Imported Frozen", trust: "Low-Medium", consistency: "Variable", portioning: "Fixed", branding: "Generic", education: "None", highlight: false },
            { title: "Meat Boutique", trust: "High (systemic)", consistency: "High", portioning: "Precision", branding: "Premium", education: "Complete", highlight: true },
          ].map((col) => (
            <div
              key={col.title}
              className={`rounded-lg p-6 border transition-all ${
                col.highlight
                  ? "border-brand-gold/40 bg-brand-gold/5"
                  : "border-white/5 bg-white/[0.02]"
              }`}
            >
              <h3 className={`font-serif text-base mb-4 ${col.highlight ? "text-brand-gold" : "text-brand-cream/70"}`}>
                {col.title}
              </h3>
              {[
                ["Trust", col.trust],
                ["Consistency", col.consistency],
                ["Portioning", col.portioning],
                ["Branding", col.branding],
                ["Education", col.education],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between py-1.5 border-b border-white/5 last:border-0">
                  <span className="font-sans text-[10px] text-brand-gray uppercase tracking-wider">{label}</span>
                  <span className={`font-sans text-[10px] tracking-wide ${col.highlight ? "text-brand-gold" : "text-brand-cream/50"}`}>
                    {value}
                  </span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </Section>

      {/* ════════ PRODUCTS ════════ */}
      <Section id="products" dark={false}>
        <SectionLabel><span className="text-brand-burgundy">The Product Universe</span></SectionLabel>
        <SectionTitle light>Curated for every<br />occasion.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-black/50 max-w-3xl leading-relaxed mb-16">
          Every product follows one naming system: Brand + Cut + Weight. No clever names.
          No poetry. The customer understands exactly what they are buying in under two seconds.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { cat: "Premium Steaks", position: "Reserve Halo", examples: "Ribeye, Tenderloin, T-Bone", feel: "Aspirational. Gift-worthy." },
            { cat: "Everyday Steaks", position: "Core Range", examples: "Striploin, Rump, Flat Iron", feel: "Reliable. Weeknight backbone." },
            { cat: "Burgers & Kafta", position: "Everyday", examples: "Angus Burger 4pc, Beef Kafta 6pc", feel: "Fun but never cheap." },
            { cat: "Mince & Strips", position: "Essential", examples: "Lean Mince 500g, Shawarma Strips", feel: "Dinner in 15 minutes." },
            { cat: "Lamb Range", position: "Premium & Everyday", examples: "Lamb Kafta, Lamb Shawarma", feel: "Cultural staple, elevated." },
            { cat: "Rub & Spice Line", position: "Brand Extension", examples: "Smokehouse Rub, Herb Salt, BBQ", feel: "The finishing touch." },
            { cat: "Curated Boxes", position: "Experience Product", examples: "Grill Master, Weeknight, Eid", feel: "Complete solution, not random." },
            { cat: "Future: Convenience", position: "Phase 2", examples: "Pre-marinated, ready-to-cook", feel: "Maximum ease, same quality." },
          ].map((p) => (
            <div key={p.cat} className="bg-white rounded-lg border border-brand-black/5 p-6 hover:shadow-lg transition-shadow duration-500">
              <span className="font-sans text-[9px] tracking-[0.2em] uppercase text-brand-burgundy/60 mb-2 block">{p.position}</span>
              <h3 className="font-serif text-lg text-brand-black mb-2">{p.cat}</h3>
              <p className="font-sans text-xs text-brand-black/40 mb-3">{p.examples}</p>
              <p className="font-sans text-xs text-brand-black/60 italic">{p.feel}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* ════════ PACKAGING ════════ */}
      <Section id="packaging">
        <SectionLabel>The Packaging System</SectionLabel>
        <SectionTitle>One master bag.<br />Infinite scale.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-cream/50 max-w-3xl leading-relaxed mb-16">
          One printed bag family in three sizes. The front design is universal. The back is universal.
          The only variable is a back-applied label — changed in seconds between production runs.
          This is not a design choice. It is a business weapon.
        </p>

        {/* Bag lineup */}
        <div className="flex items-end justify-center gap-6 md:gap-10 mb-16">
          <div className="flex flex-col items-center gap-3">
            <BagMockup size="sm" cutName="Beef Strips" weight="300g" />
            <span className="font-sans text-[9px] text-brand-gray tracking-widest uppercase">Small</span>
            <span className="font-sans text-[8px] text-brand-gray/50">150 x 220mm</span>
          </div>
          <div className="flex flex-col items-center gap-3">
            <BagMockup size="md" cutName="Angus Ribeye" weight="350g · Dry Aged" reserve />
            <span className="font-sans text-[9px] text-brand-gray tracking-widest uppercase">Medium</span>
            <span className="font-sans text-[8px] text-brand-gray/50">180 x 270mm</span>
          </div>
          <div className="flex flex-col items-center gap-3">
            <BagMockup size="lg" cutName="Grill Bundle" weight="800g · Family" />
            <span className="font-sans text-[9px] text-brand-gray tracking-widest uppercase">Large</span>
            <span className="font-sans text-[8px] text-brand-gray/50">220 x 320mm</span>
          </div>
        </div>

        {/* Spec cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <FeatureCard
            title="Front: 22 / 56 / 22"
            description="Black top band with gold branding. Transparent window showing the product. Black bottom band with cut name and weight. Same across every SKU."
          />
          <FeatureCard
            title="Back: Applied Label"
            description="Matte cream synthetic stock. Thermal transfer print. Bilingual EN/AR. QR code linking to cooking guides. Changed per SKU in seconds."
          />
          <FeatureCard
            title="Material: PA/PE 90µ"
            description="Co-extruded multi-layer film. Matte lamination. 2-color rotogravure (Black + Gold PMS 871C). USD 0.08–0.15 per bag."
          />
        </div>

        {/* Cost advantage callout */}
        <div className="border border-brand-gold/20 rounded-lg p-8 md:p-12 text-center bg-brand-gold/[0.03]">
          <p className="font-serif text-2xl md:text-3xl text-brand-gold mb-4">
            One plate set. Three sizes. Every SKU.
          </p>
          <p className="font-sans text-sm text-brand-gray max-w-2xl mx-auto">
            Competitors who print per-SKU bags spend USD 800–1,500 per cylinder set with
            10,000+ minimum runs. Our system eliminates that entirely. The master bag never changes.
            The label does the work.
          </p>
        </div>
      </Section>

      {/* ════════ BOX EXPERIENCE ════════ */}
      <Section id="box">
        <SectionLabel>The Premium Box</SectionLabel>
        <SectionTitle>Two tiers.<br />One standard.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-cream/50 max-w-3xl leading-relaxed mb-16">
          The box is where Meat Boutique becomes a brand experience. In Lebanon, where food is
          social currency, the box is the brand&apos;s handshake.
        </p>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {/* Signature Box */}
          <div className="relative rounded-xl overflow-hidden border border-brand-gold/20">
            <div className="bg-brand-black p-8 md:p-10">
              <div className="w-full h-48 bg-gradient-to-b from-brand-black to-[#1a0a14] rounded-lg flex items-center justify-center mb-8 border border-white/5">
                <div className="text-center">
                  <span className="font-serif text-xl text-brand-gold tracking-[0.2em] font-bold block">MEAT<br/>BOUTIQUE</span>
                  <div className="w-10 h-px bg-brand-gold mx-auto mt-2 mb-2" />
                  <div className="w-full h-4 bg-gradient-to-r from-transparent via-brand-burgundy/40 to-transparent mt-4" />
                </div>
              </div>
              <span className="inline-block font-sans text-[9px] tracking-[0.2em] uppercase bg-brand-burgundy text-brand-gold px-3 py-1 rounded-full mb-4">
                Tier 1 — Signature Box
              </span>
              <h3 className="font-serif text-2xl text-brand-gold mb-3">The statement piece</h3>
              <p className="font-sans text-sm text-brand-gray leading-relaxed mb-6">
                Rigid magnetic-close box. Matte black exterior with soft-touch finish.
                Gold foil wordmark. Deep burgundy interior lining. Die-cut product tray.
                Welcome card + rub sachet included.
              </p>
              <div className="flex gap-2 flex-wrap">
                {["First Order", "Gifting", "Eid", "Seasonal"].map((tag) => (
                  <span key={tag} className="font-sans text-[9px] tracking-wider uppercase px-3 py-1 rounded-full border border-brand-gold/20 text-brand-gold/70">
                    {tag}
                  </span>
                ))}
              </div>
              <p className="font-sans text-xs text-brand-gray/50 mt-4">$4–7 per unit · Orders above $60</p>
            </div>
          </div>

          {/* Service Box */}
          <div className="relative rounded-xl overflow-hidden border border-white/5">
            <div className="bg-brand-darkgray p-8 md:p-10">
              <div className="w-full h-48 bg-[#151515] rounded-lg flex items-center justify-center mb-8 border border-white/5 relative">
                <div className="absolute top-0 left-0 right-0 h-1 bg-brand-burgundy" />
                <div className="text-center">
                  <span className="font-serif text-lg text-brand-gold tracking-[0.15em] font-bold block">MEAT<br/>BOUTIQUE</span>
                  <div className="w-8 h-px bg-brand-gold mx-auto mt-2" />
                  <span className="font-sans text-[8px] text-brand-gold/50 tracking-[0.2em] uppercase block mt-2">Your Weekly Selection</span>
                </div>
              </div>
              <span className="inline-block font-sans text-[9px] tracking-[0.2em] uppercase bg-brand-black text-brand-gold px-3 py-1 rounded-full mb-4">
                Tier 2 — Service Box
              </span>
              <h3 className="font-serif text-2xl text-brand-gold mb-3">The reliable delivery</h3>
              <p className="font-sans text-sm text-brand-gray leading-relaxed mb-6">
                Premium E-flute corrugated. Matte black print with gold wordmark.
                Thin burgundy accent line. Insulated interior. Recipe card included.
                Practical, premium, sustainable.
              </p>
              <div className="flex gap-2 flex-wrap">
                {["Weekly", "Biweekly", "App Delivery", "Repeat"].map((tag) => (
                  <span key={tag} className="font-sans text-[9px] tracking-wider uppercase px-3 py-1 rounded-full border border-white/10 text-brand-gray">
                    {tag}
                  </span>
                ))}
              </div>
              <p className="font-sans text-xs text-brand-gray/50 mt-4">$1.50–2.50 per unit · All orders</p>
            </div>
          </div>
        </div>

        {/* Unboxing sequence */}
        <div className="border border-brand-gold/10 rounded-lg p-8 md:p-12">
          <h3 className="font-serif text-xl text-brand-gold mb-8 text-center">The Signature Box Unboxing</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { step: "01", title: "First Sight", desc: "Matte black, gold foil, burgundy stripe" },
              { step: "02", title: "Magnetic Open", desc: "1.5-second controlled reveal" },
              { step: "03", title: "Interior Reveal", desc: "Deep burgundy, welcome card on top" },
              { step: "04", title: "Product Display", desc: "4–6 bags face-up, curated layout" },
              { step: "05", title: "Hidden Layer", desc: "Thawing guide + QR education card" },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <span className="font-serif text-2xl text-brand-gold/30 block mb-2">{s.step}</span>
                <span className="font-sans text-xs text-brand-gold tracking-wide uppercase block mb-1">{s.title}</span>
                <span className="font-sans text-[10px] text-brand-gray leading-relaxed">{s.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ════════ TRUST ════════ */}
      <Section id="trust" dark={false}>
        <SectionLabel><span className="text-brand-burgundy">Trust &amp; Education</span></SectionLabel>
        <SectionTitle light>Frozen is not<br />a compromise.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-black/50 max-w-3xl leading-relaxed mb-16">
          The brand is engineered to systematically dismantle frozen stigma
          and replace it with a new truth: professional freezing is a quality-control advantage.
        </p>

        <div className="grid md:grid-cols-5 gap-6 mb-16">
          {[
            { icon: "◆", title: "Flash-Frozen", desc: "Locked in at peak freshness within hours of processing." },
            { icon: "◇", title: "No Additives", desc: "Zero preservatives. Freezing is the preservation." },
            { icon: "▣", title: "Precision Cut", desc: "Portioned to exact spec. No guesswork." },
            { icon: "◈", title: "Traceable", desc: "Lot number on every pack. Source to freezer." },
            { icon: "▢", title: "Safest Storage", desc: "Below -18°C, bacteria cannot grow. Period." },
          ].map((t) => (
            <div key={t.title} className="text-center">
              <div className="w-14 h-14 rounded-full border border-brand-black/10 mx-auto mb-4 flex items-center justify-center text-brand-burgundy text-lg">
                {t.icon}
              </div>
              <h3 className="font-sans text-xs tracking-[0.15em] uppercase text-brand-black font-semibold mb-2">{t.title}</h3>
              <p className="font-sans text-xs text-brand-black/50 leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            { title: "How to Thaw", desc: "Fridge overnight. Remove 30 minutes before cooking. Pat dry. Never microwave from frozen." },
            { title: "How to Cook", desc: "Each cut has a specific guide. Temperature, timing, technique — accessible via QR code on every pack." },
            { title: "Why Frozen Wins", desc: "Flash-freezing locks freshness better than any display case. Your butcher's meat has been exposed for hours." },
          ].map((e) => (
            <div key={e.title} className="bg-white rounded-lg border border-brand-black/5 p-6">
              <h3 className="font-serif text-lg text-brand-black mb-2">{e.title}</h3>
              <p className="font-sans text-xs text-brand-black/50 leading-relaxed">{e.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* ════════ CHANNELS ════════ */}
      <Section id="channels">
        <SectionLabel>How It Reaches You</SectionLabel>
        <SectionTitle>Four channels.<br />One experience.</SectionTitle>

        <div className="grid md:grid-cols-4 gap-6 mb-16">
          {[
            { channel: "App Commerce", sub: "Toters · NokNok", status: "Launch", desc: "Primary sales channel. Lebanese consumers already trained to order through apps." },
            { channel: "D2C Website", sub: "meatboutique.com", status: "Phase 2", desc: "Full e-commerce with box builder, repeat orders, and education hub." },
            { channel: "Premium Retail", sub: "Selected stores", status: "Phase 2", desc: "Gourmet stores and premium grocers. Never supermarket freezer aisle." },
            { channel: "HORECA", sub: "Restaurants & Hotels", status: "Future", desc: "Same product, HORECA label. Credibility halo for the consumer brand." },
          ].map((c) => (
            <div key={c.channel} className="border border-white/5 bg-white/[0.02] rounded-lg p-6 hover:border-brand-gold/15 transition-colors">
              <span className={`inline-block font-sans text-[8px] tracking-[0.2em] uppercase px-2 py-0.5 rounded-full mb-3 ${
                c.status === "Launch" ? "bg-brand-gold/10 text-brand-gold" : "bg-white/5 text-brand-gray"
              }`}>
                {c.status}
              </span>
              <h3 className="font-serif text-lg text-brand-gold mb-1">{c.channel}</h3>
              <p className="font-sans text-[10px] text-brand-gray/60 tracking-wider uppercase mb-3">{c.sub}</p>
              <p className="font-sans text-xs text-brand-gray leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>

        {/* Customer journey */}
        <div className="border border-brand-gold/10 rounded-lg p-8 md:p-12">
          <h3 className="font-serif text-xl text-brand-gold mb-8 text-center">The Repeat Loop</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Discovery", desc: "Via app, social, or influencer" },
              { step: "2", title: "First Order", desc: "Signature Box exceeds expectations" },
              { step: "3", title: "Repeat", desc: "Retarget at 14 days, suggest curated box" },
              { step: "4", title: "Subscribe", desc: "5–10% discount for weekly commitment" },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="w-10 h-10 rounded-full border border-brand-gold/30 mx-auto mb-3 flex items-center justify-center font-serif text-brand-gold text-lg">
                  {s.step}
                </div>
                <span className="font-sans text-xs text-brand-gold tracking-wide uppercase block mb-1">{s.title}</span>
                <span className="font-sans text-[10px] text-brand-gray">{s.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ════════ PLATFORM ════════ */}
      <Section id="platform" dark={false}>
        <SectionLabel><span className="text-brand-burgundy">The Platform</span></SectionLabel>
        <SectionTitle light>Three layers.<br />One integrated system.</SectionTitle>
        <p className="font-sans text-sm md:text-base text-brand-black/50 max-w-3xl leading-relaxed mb-16">
          No competitor in Lebanon has this vertical chain under one roof.
          That is the moat.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {[
            {
              layer: "GFS",
              role: "Sourcing Engine",
              desc: "Import, wholesale, raw-material cost control. The upstream supply platform that gives Meat Boutique pricing power no competitor can match.",
              color: "border-t-brand-gray",
            },
            {
              layer: "Prime Lab",
              role: "Manufacturing Platform",
              desc: "Processing, portioning, quality control, packaging. Transforms imported carcass into consumer-ready SKUs with full traceability.",
              color: "border-t-brand-burgundy",
            },
            {
              layer: "Meat Boutique",
              role: "Consumer Brand",
              desc: "Design, education, customer experience, channel management. The visible face that builds trust and drives premium margin.",
              color: "border-t-brand-gold",
            },
          ].map((l) => (
            <div
              key={l.layer}
              className={`bg-white rounded-lg border border-brand-black/5 border-t-2 ${l.color} p-8`}
            >
              <span className="font-sans text-[9px] tracking-[0.2em] uppercase text-brand-black/30 block mb-2">{l.role}</span>
              <h3 className="font-serif text-2xl text-brand-black mb-3">{l.layer}</h3>
              <p className="font-sans text-sm text-brand-black/50 leading-relaxed">{l.desc}</p>
            </div>
          ))}
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-brand-black rounded-lg p-6 text-center">
            <div className="font-serif text-3xl text-brand-gold font-bold mb-1">$35–50</div>
            <div className="font-sans text-[10px] text-brand-gray tracking-wider uppercase">Target AOV</div>
          </div>
          <div className="bg-brand-black rounded-lg p-6 text-center">
            <div className="font-serif text-3xl text-brand-gold font-bold mb-1">40%</div>
            <div className="font-sans text-[10px] text-brand-gray tracking-wider uppercase">Repeat in 90 Days</div>
          </div>
          <div className="bg-brand-black rounded-lg p-6 text-center">
            <div className="font-serif text-3xl text-brand-gold font-bold mb-1">10–12</div>
            <div className="font-sans text-[10px] text-brand-gray tracking-wider uppercase">Launch SKUs</div>
          </div>
          <div className="bg-brand-black rounded-lg p-6 text-center">
            <div className="font-serif text-3xl text-brand-gold font-bold mb-1">3</div>
            <div className="font-sans text-[10px] text-brand-gray tracking-wider uppercase">Launch Channels</div>
          </div>
        </div>
      </Section>

      {/* ════════ GROWTH ════════ */}
      <Section id="growth">
        <SectionLabel>Future Growth</SectionLabel>
        <SectionTitle>Built to scale<br />from day one.</SectionTitle>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard title="GCC Export" description="Same master bag, regional back label. Brand name reads internationally. Visual identity is culturally neutral." />
          <FeatureCard title="Subscription Model" description="Weekly curated box. Proven repeat behavior converts to 5–10% discount subscription after 3rd order." />
          <FeatureCard title="HORECA Credibility" description="3–5 respected restaurants serving Meat Boutique creates a trust halo no social media can replicate." />
          <FeatureCard title="Seasonal Gifting" description="Eid, holidays, summer grill boxes. The Signature Box is already designed for it." />
          <FeatureCard title="Rub & Spice Line" description="$5–8 gateway product. Gets the brand into kitchens before the meat does." />
          <FeatureCard title="Content Authority" description="If Meat Boutique owns frozen education in Lebanon, it owns the category. Content is the long-term moat." accent />
        </div>
      </Section>

      {/* ════════ CTA ════════ */}
      <section className="relative py-32 px-6 md:px-12 bg-gradient-to-b from-brand-black via-[#1a0a14] to-brand-black">
        <div className="max-w-3xl mx-auto text-center">
          <GoldDivider className="mb-8" />
          <h2 className="font-serif text-3xl md:text-5xl text-brand-gold font-bold tracking-wide mb-6">
            The category is open.
          </h2>
          <p className="font-sans text-sm text-brand-cream/50 max-w-xl mx-auto leading-relaxed mb-10">
            The brand that launches with 10 perfect SKUs, seeds 15 creators with
            cooking-outcome briefs, and teaches Lebanese households why their freezer
            is the smartest place for protein will own this category within 18 months.
          </p>
          <a
            href="mailto:hello@meatboutique.com"
            className="inline-block px-10 py-4 border border-brand-gold text-brand-gold font-sans text-xs tracking-[0.2em] uppercase font-semibold rounded-sm hover:bg-brand-gold hover:text-brand-black transition-all duration-300"
          >
            Begin the Conversation
          </a>
        </div>
      </section>

      {/* ════════ FOOTER ════════ */}
      <footer id="footer" className="relative bg-brand-black border-t border-brand-gold/10 py-12 px-6 md:px-12">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-burgundy to-transparent" />
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <span className="font-serif text-brand-gold tracking-[0.2em] text-sm font-bold">
            MEAT BOUTIQUE
          </span>
          <div className="flex gap-8">
            {["Vision", "Product", "Packaging", "Experience", "Platform"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`} className="font-sans text-[10px] tracking-[0.15em] uppercase text-brand-gray hover:text-brand-gold transition-colors">
                {l}
              </a>
            ))}
          </div>
          <span className="font-sans text-[10px] text-brand-gray/40 tracking-wider">
            Confidential — Board Presentation 2026
          </span>
        </div>
      </footer>
    </main>
  );
}
